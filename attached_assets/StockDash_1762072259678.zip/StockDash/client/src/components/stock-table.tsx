import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowUpDown, ArrowUp, ArrowDown, ArrowUpRight, ArrowDownRight, TrendingUp, TrendingDown, MessageSquare, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Stock, User, StockInterestWithUser } from "@shared/schema";
import { MiniCandlestickChart } from "@/components/mini-candlestick-chart";

interface StockTableProps {
  stocks: Stock[];
  users: User[];
  interests: StockInterestWithUser[];
  commentCounts: { ticker: string; count: number }[];
  analyses?: any[];
  selectedTickers?: Set<string>;
  onToggleSelection?: (ticker: string) => void;
  onSelectAll?: (tickers: string[]) => void;
  onStockClick: (stock: Stock) => void;
  viewedTickers?: string[];
}

type SortField = "ticker" | "price" | "change" | "insiderPrice" | "marketCap" | "recommendation" | "aiScore" | "daysFromBuy";
type SortDirection = "asc" | "desc";

export function StockTable({ 
  stocks, 
  users, 
  interests, 
  commentCounts, 
  analyses = [], 
  selectedTickers = new Set(),
  onToggleSelection,
  onSelectAll,
  onStockClick,
  viewedTickers = []
}: StockTableProps) {
  const [sortField, setSortField] = useState<SortField>("ticker");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  
  const allSelected = stocks.length > 0 && stocks.every(s => selectedTickers.has(s.ticker));
  const someSelected = stocks.some(s => selectedTickers.has(s.ticker)) && !allSelected;
  
  const handleSelectAll = () => {
    if (onSelectAll) {
      if (allSelected) {
        onSelectAll([]);
      } else {
        onSelectAll(stocks.map(s => s.ticker));
      }
    }
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const getInitials = (name: string) => {
    return name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const getStockInterests = (ticker: string) => {
    return interests.filter(i => i.ticker === ticker);
  };

  const getCommentCount = (ticker: string) => {
    return commentCounts.find(c => c.ticker === ticker)?.count || 0;
  };

  const getAIAnalysis = (ticker: string) => {
    return analyses.find(a => a.ticker === ticker);
  };

  // Check if a stock was added recently (within last 48 hours) and not viewed by current user
  const isNewStock = (ticker: string, insiderTradeDate: string | null): boolean => {
    if (!insiderTradeDate) return false;
    
    // Check if current user has viewed this stock
    if (viewedTickers.includes(ticker)) return false;
    
    const tradeDate = new Date(insiderTradeDate);
    const now = new Date();
    const hoursSinceAdded = (now.getTime() - tradeDate.getTime()) / (1000 * 60 * 60);
    return hoursSinceAdded <= 48;
  };

  // Calculate days since insider purchased the stock
  const getDaysFromBuy = (insiderTradeDate: string | null): number => {
    if (!insiderTradeDate) return 0;
    const tradeDate = new Date(insiderTradeDate);
    const now = new Date();
    const daysDiff = Math.floor((now.getTime() - tradeDate.getTime()) / (1000 * 60 * 60 * 24));
    return daysDiff;
  };

  const sortedStocks = [...stocks].sort((a, b) => {
    let compareA: any;
    let compareB: any;

    switch (sortField) {
      case "ticker":
        compareA = a.ticker;
        compareB = b.ticker;
        break;
      case "price":
        compareA = parseFloat(a.currentPrice);
        compareB = parseFloat(b.currentPrice);
        break;
      case "change":
        const changeA = parseFloat(a.currentPrice) - parseFloat(a.previousClose || a.currentPrice);
        const changeB = parseFloat(b.currentPrice) - parseFloat(b.previousClose || b.currentPrice);
        compareA = changeA;
        compareB = changeB;
        break;
      case "insiderPrice":
        compareA = a.insiderPrice ? parseFloat(a.insiderPrice) : 0;
        compareB = b.insiderPrice ? parseFloat(b.insiderPrice) : 0;
        break;
      case "marketCap":
        const getMarketCapValue = (mcStr: string | null) => {
          if (!mcStr) return 0;
          // Match patterns like "$1.2M", "500M", "$1.5B", "2.3T"
          const match = mcStr.match(/\$?([\d.]+)\s*([KMBT])?/i);
          if (!match) return 0;
          
          const value = parseFloat(match[1]);
          const suffix = match[2]?.toUpperCase();
          
          // Convert to millions for consistent comparison
          switch (suffix) {
            case 'K': return value / 1000; // Thousands to millions
            case 'M': return value; // Already in millions
            case 'B': return value * 1000; // Billions to millions
            case 'T': return value * 1000000; // Trillions to millions
            default: return value; // No suffix, assume millions
          }
        };
        compareA = getMarketCapValue(a.marketCap);
        compareB = getMarketCapValue(b.marketCap);
        break;
      case "recommendation":
        compareA = a.recommendation || "";
        compareB = b.recommendation || "";
        break;
      case "aiScore":
        const analysisA = getAIAnalysis(a.ticker);
        const analysisB = getAIAnalysis(b.ticker);
        compareA = analysisA?.financialHealthScore || 0;
        compareB = analysisB?.financialHealthScore || 0;
        break;
      case "daysFromBuy":
        compareA = getDaysFromBuy(a.insiderTradeDate);
        compareB = getDaysFromBuy(b.insiderTradeDate);
        break;
      default:
        compareA = a.ticker;
        compareB = b.ticker;
    }

    if (compareA < compareB) return sortDirection === "asc" ? -1 : 1;
    if (compareA > compareB) return sortDirection === "asc" ? 1 : -1;
    return 0;
  });

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4 ml-1" />;
    return sortDirection === "asc" ? 
      <ArrowUp className="h-4 w-4 ml-1" /> : 
      <ArrowDown className="h-4 w-4 ml-1" />;
  };

  return (
    <div className="rounded-md border overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12">
              {onSelectAll && (
                <Checkbox
                  checked={allSelected}
                  onCheckedChange={handleSelectAll}
                  aria-label="Select all"
                  data-testid="checkbox-select-all"
                />
              )}
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("ticker")}
                className="h-8 px-2"
                data-testid="sort-ticker"
              >
                Ticker
                <SortIcon field="ticker" />
              </Button>
            </TableHead>
            <TableHead className="hidden md:table-cell">Company</TableHead>
            <TableHead>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("recommendation")}
                className="h-8 px-2"
                data-testid="sort-recommendation"
              >
                Rec.
                <SortIcon field="recommendation" />
              </Button>
            </TableHead>
            <TableHead className="text-right">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("price")}
                className="h-8 px-2"
                data-testid="sort-price"
              >
                Price
                <SortIcon field="price" />
              </Button>
            </TableHead>
            <TableHead className="hidden lg:table-cell">Trend (2wk)</TableHead>
            <TableHead className="text-right">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("change")}
                className="h-8 px-2"
                data-testid="sort-change"
              >
                Change
                <SortIcon field="change" />
              </Button>
            </TableHead>
            <TableHead className="text-right hidden xl:table-cell">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("insiderPrice")}
                className="h-8 px-2"
                data-testid="sort-insider-price"
              >
                Insider $
                <SortIcon field="insiderPrice" />
              </Button>
            </TableHead>
            <TableHead className="hidden xl:table-cell">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("marketCap")}
                className="h-8 px-2"
                data-testid="sort-market-cap"
              >
                Mkt Cap
                <SortIcon field="marketCap" />
              </Button>
            </TableHead>
            <TableHead className="text-right hidden 2xl:table-cell">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("aiScore")}
                className="h-8 px-2"
                data-testid="sort-ai-score"
              >
                AI Score
                <SortIcon field="aiScore" />
              </Button>
            </TableHead>
            <TableHead className="hidden lg:table-cell">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleSort("daysFromBuy")}
                className="h-8 px-2"
                data-testid="sort-days-from-buy"
              >
                Days
                <SortIcon field="daysFromBuy" />
              </Button>
            </TableHead>
            <TableHead className="hidden sm:table-cell">Interest</TableHead>
            <TableHead className="hidden sm:table-cell">Comments</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedStocks.map((stock) => {
            const currentPrice = parseFloat(stock.currentPrice);
            const previousPrice = parseFloat(stock.previousClose || stock.currentPrice);
            const priceChange = currentPrice - previousPrice;
            const priceChangePercent = (priceChange / previousPrice) * 100;
            const isPositive = priceChange >= 0;
            const insiderPrice = stock.insiderPrice ? parseFloat(stock.insiderPrice) : null;
            const stockInterests = getStockInterests(stock.ticker);

            return (
              <TableRow
                key={stock.id}
                className="cursor-pointer hover-elevate"
                onClick={() => onStockClick(stock)}
                data-testid={`row-stock-${stock.ticker}`}
              >
                <TableCell 
                  className="w-12" 
                  onClick={(e) => e.stopPropagation()}
                >
                  {onToggleSelection && (
                    <Checkbox
                      checked={selectedTickers.has(stock.ticker)}
                      onCheckedChange={() => onToggleSelection(stock.ticker)}
                      aria-label={`Select ${stock.ticker}`}
                      data-testid={`checkbox-${stock.ticker}`}
                    />
                  )}
                </TableCell>
                <TableCell className="font-medium font-mono" data-testid={`cell-ticker-${stock.ticker}`}>
                  <div className="flex items-center gap-2">
                    <span>{stock.ticker}</span>
                    {isNewStock(stock.ticker, stock.insiderTradeDate) && (
                      <Badge variant="default" className="text-xs px-1.5 py-0" data-testid={`badge-new-${stock.ticker}`}>
                        NEW
                      </Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell max-w-xs truncate text-sm text-muted-foreground" data-testid={`cell-company-${stock.ticker}`}>
                  {stock.companyName}
                </TableCell>
                <TableCell>
                  {stock.recommendation && (
                    <Badge
                      variant={stock.recommendation.toLowerCase().includes("buy") ? "default" : "destructive"}
                      className="text-xs"
                      data-testid={`badge-rec-${stock.ticker}`}
                    >
                      {stock.recommendation.toLowerCase().includes("buy") ? (
                        <ArrowUpRight className="h-3 w-3 mr-1" />
                      ) : (
                        <ArrowDownRight className="h-3 w-3 mr-1" />
                      )}
                      {stock.recommendation.replace("_", " ").toUpperCase()}
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right font-mono" data-testid={`cell-price-${stock.ticker}`}>
                  ${currentPrice.toFixed(2)}
                </TableCell>
                <TableCell className="hidden lg:table-cell w-32" data-testid={`cell-chart-${stock.ticker}`}>
                  {stock.candlesticks && stock.candlesticks.length > 0 ? (
                    <div className="h-12">
                      <MiniCandlestickChart data={stock.candlesticks} height={48} />
                    </div>
                  ) : (
                    <span className="text-xs text-muted-foreground">-</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className={`flex items-center justify-end gap-1 ${isPositive ? "text-success" : "text-destructive"}`}>
                    {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    <span className="text-xs font-mono font-medium">
                      {isPositive ? "+" : ""}{priceChangePercent.toFixed(2)}%
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-right font-mono text-sm text-muted-foreground hidden xl:table-cell">
                  {insiderPrice ? `$${insiderPrice.toFixed(2)}` : "-"}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground hidden xl:table-cell">
                  {stock.marketCap || "-"}
                </TableCell>
                <TableCell className="text-right hidden 2xl:table-cell" data-testid={`cell-ai-score-${stock.ticker}`}>
                  {(() => {
                    const analysis = getAIAnalysis(stock.ticker);
                    if (!analysis) return <span className="text-xs text-muted-foreground">-</span>;
                    
                    // Check if analysis is in progress
                    if (analysis.status === "pending" || analysis.status === "analyzing") {
                      return (
                        <Badge variant="outline" className="text-xs">
                          Analyzing...
                        </Badge>
                      );
                    }
                    
                    // Show error state
                    if (analysis.status === "failed") {
                      return (
                        <Badge variant="destructive" className="text-xs">
                          Error
                        </Badge>
                      );
                    }
                    
                    const score = analysis.financialHealthScore;
                    const rating = analysis.overallRating;
                    let badgeVariant: "default" | "secondary" | "destructive" | "outline" = "secondary";
                    
                    if (rating === "buy" || rating === "strong_buy") badgeVariant = "default";
                    else if (rating === "avoid" || rating === "sell" || rating === "strong_avoid") badgeVariant = "destructive";
                    
                    return (
                      <Badge variant={badgeVariant} className="text-xs font-mono">
                        {score}/100
                      </Badge>
                    );
                  })()}
                </TableCell>
                <TableCell className="hidden lg:table-cell">
                  {stock.insiderTradeDate && (
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground" data-testid={`text-days-from-buy-${stock.ticker}`}>
                      <Clock className="h-3 w-3" />
                      <span>{getDaysFromBuy(stock.insiderTradeDate)}d</span>
                    </div>
                  )}
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  <div className="flex gap-1">
                    {stockInterests.map((interest) => (
                      <Avatar
                        key={interest.id}
                        className="h-6 w-6"
                        style={{ backgroundColor: interest.user.avatarColor }}
                        data-testid={`avatar-interest-${stock.ticker}-${interest.user.name.toLowerCase()}`}
                      >
                        <AvatarFallback
                          className="text-white text-xs"
                          style={{ backgroundColor: interest.user.avatarColor }}
                        >
                          {getInitials(interest.user.name)}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  {getCommentCount(stock.ticker) > 0 && (
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <MessageSquare className="h-4 w-4" />
                      <span className="text-sm" data-testid={`text-comment-count-${stock.ticker}`}>
                        {getCommentCount(stock.ticker)}
                      </span>
                    </div>
                  )}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
